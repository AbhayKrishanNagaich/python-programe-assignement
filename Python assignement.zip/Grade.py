a=int(input("Enter marks "))
b=int(input("Enter marks "))
c=int(input("Enter marks "))
d=int(input("Enter marks "))
e=int(input("Enter marks "))
f=(a+b+c+d+e)/5
if(f>=90):
    print("Grade A")
elif(f>=80):
    print("Grade B")
elif(f>=70):
    print("Grade C")
elif(f>=60):
    print("Grade D")
elif(f>=40):
    print("Grade E")
else:
    print("Grade F")
    

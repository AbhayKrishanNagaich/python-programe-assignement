import os

file_size = os.path.getsize("filename.txt")
print(file_size)

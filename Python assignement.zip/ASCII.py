a=int(input("Enter the Number here:"))
print(chr(a))
    
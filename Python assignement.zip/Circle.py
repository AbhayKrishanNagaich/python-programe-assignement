a=float(input())
print("Area=%f"%(3.14*a**2))
print("Circumference=%f"%(2*3.14*a))
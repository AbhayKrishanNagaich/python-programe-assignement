a=input("Enter the alphabet: ")
if(a=="a" or a=="i" or a=="e" or a=="o" or a=="u"):
    print("Vowel")
else:
    print("Consonant")
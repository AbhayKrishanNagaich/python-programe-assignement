file = open("filename.txt", "r")
content = file.read()
print(content)
file.close()

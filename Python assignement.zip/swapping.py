a=int(input())
b=int(input())
c=a
a=b
b=c
print("a=%d and b=%d"%(a,b))
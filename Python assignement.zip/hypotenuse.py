a=int(input("Hieght"))
b=int(input("Base"))
c=a**2+b**2
print("Hypotenuse=%f"%(c**0.5))

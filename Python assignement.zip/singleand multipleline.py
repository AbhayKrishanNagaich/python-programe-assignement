print("Hello World")
print('''Hello
world''')
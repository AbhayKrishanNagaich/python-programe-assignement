i=97
while(i<123):
    print(chr(i))
    i=i+1